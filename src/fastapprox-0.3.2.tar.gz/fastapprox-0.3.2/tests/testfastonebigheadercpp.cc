#include "../src/fastonebigheader.h"

int
main (void)
{
  return fastexp (1) < 0;
}
